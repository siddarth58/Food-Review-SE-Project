/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author hp
 */
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    @Override
     protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String first_name = request.getParameter("first_name");
		String last_name = request.getParameter("last_name");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String city = request.getParameter("address");
		String contact = request.getParameter("contact");
		
		if(first_name.isEmpty() || last_name.isEmpty() || username.isEmpty() || 
				password.isEmpty() || city.isEmpty() || contact.isEmpty())
		{
			RequestDispatcher req = request.getRequestDispatcher("register.jsp");
			req.include(request, response);
		}
		else
		{
                           boolean status;
                    try{
                        try {
                            Connection con = DatabaseConnection.initializeDatabase();
                            CallableStatement procstate = con.prepareCall("{?= call sf_register(?,?,?,?,?,?)}");  
                            //call sp_register('jeevan','kethineni','kjeevan@gmail.com','abcdf','989768909','Khammam')
                        procstate.registerOutParameter(1, Types.BOOLEAN);
                        procstate.setString(2, first_name);
                        procstate.setString(3, last_name);
                        procstate.setString(4, username);
                        procstate.setString(5, password);
                        procstate.setString(6, contact);
                        procstate.setString(7, city);
                        boolean rs = procstate.execute();
                        if(procstate.getInt(1) == 1){
                            request.setAttribute("alertMsg", "Registered Successfully!!!  Please login");
                            RequestDispatcher req = request.getRequestDispatcher("login.jsp");
                            req.forward(request, response);
                        }
                        else{
                            request.setAttribute("registerMsg", "Usrname already exists, please try with new username");
                            RequestDispatcher req = request.getRequestDispatcher("register.jsp");
                            req.forward(request, response);
                        }
                        } catch (ClassNotFoundException ex) {
                            Logger.getLogger(register.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                    }
                    catch(SQLException ex){
                      int a=10;
                      if(a>10){
                          
                      }
                    }
                    
                    
			
		}
	}

}