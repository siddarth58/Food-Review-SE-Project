/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import Controller.DatabaseConnection;
import java.sql.PreparedStatement;

import java.sql.Connection;
import java.sql.CallableStatement;
import java.sql.Types;
import java.util.ArrayList;
import java.sql.ResultSet;

/**
 *
 * @author hp
 */
public class login extends HttpServlet {

    public login(){
        super();
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		if(username.isEmpty() || password.isEmpty() )
		{
			RequestDispatcher req = request.getRequestDispatcher("login.jsp");
			req.include(request, response);
		}
		else
		{
                    try{
                        Connection con = DatabaseConnection.initializeDatabase();
                        CallableStatement st = con.prepareCall("{?=call SF_ValidateLogin(?, ?)}");
  
            // For the first parameter,
            // get the data using request object
            // sets the data to st pointer
                        st.registerOutParameter(1, Types.BOOLEAN);

            st.setString(2,username);
  
            // Same for second parameter
            st.setString(3, password);
  
            // Execute the insert command using executeUpdate()
            // to make changes in database
            boolean rs= st.execute();
            if(st.getInt(1) == 1){
                
                    ArrayList<String[]> dataList = new ArrayList<String[]>();

                    String sql = "SELECT * FROM foodcategories";
                    PreparedStatement  stmt = con.prepareStatement(sql);
                    ResultSet  Categoryres = stmt.executeQuery();

                    while (Categoryres.next()) {                        
                        String[] rowData = new String[5]; // Change the array size according to the number of columns
                        rowData[0] = Categoryres.getString("category");
                        rowData[1] = Categoryres.getString("product");
                        rowData[2] = Categoryres.getString("Ingredients");
                        rowData[3] = Categoryres.getString("Comments");
                        rowData[4] = Categoryres.getString("HealthBenefits");
                        // Add the array of data to the ArrayList
                        dataList.add(rowData);
                    }
               
                        RequestDispatcher req = request.getRequestDispatcher("loginsuccess.jsp");
                            request.setAttribute("CategoryData", dataList);
			req.forward(request, response);
            }
            else{
                request.setAttribute("alertMsg", "Incorrect Credentials");
                RequestDispatcher req = request.getRequestDispatcher("login.jsp");
			req.forward(request, response);
            }
            // Close all the connections
            st.close();
            con.close();        
                        
                    }
                    catch (Exception e) {
                        System.out.println("exception to DB");                        
                        e.printStackTrace();
                    }
			
		}
	}

}

